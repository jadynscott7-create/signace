SIGNACE MULTI-PAGE WEBSITE

Upload all files in this folder to the root of your GitHub Pages repository.

Pages:
- index.html          Home
- about.html          About Us
- projects.html       Projects / Work
- capabilities.html   Capabilities
- contact.html        Contact

All navigation is connected with relative links, so it remains one website:
signace.com.au/
signace.com.au/about.html
signace.com.au/projects.html
signace.com.au/capabilities.html
signace.com.au/contact.html
